# Conversão Extrema — Design System (React + Tailwind)

Design system em **React + Tailwind CSS**, com **tema claro e escuro**. O foco é a
**biblioteca de componentes** (`src/components/ui`); a documentação de tokens, o
showcase e a landing page são **exemplos** que mostram os componentes em uso.

Estética: clean e refinada — superfícies brancas, bordas de 1px sutis, tipografia
Geist com escala calibrada, acento esmeralda e botões premium (gradiente + borda
esmeralda giratória nos CTAs).

## Como rodar

Requer **Node.js 18+**.

```bash
cd react-app
npm install
npm run dev
```

Abra o endereço que o Vite mostrar (geralmente `http://localhost:5173`). Use o
alternador no rodapé para navegar entre **Foundations** (tokens), **Componentes**
(galeria) e a **Landing** de exemplo, e o botão de sol/lua para alternar o tema.

Build de produção:

```bash
npm run build && npm run preview
```

## Estrutura

```
react-app/
├─ vite.config.js            # Vite + plugins Tailwind e Cloudflare
├─ index.html                # script anti-flash de tema + root
├─ src/
│  ├─ index.css              # ⭐ DESIGN TOKENS (@theme) — fonte única de verdade
│                            #    (cor, tipografia, espaçamento, raio, elevação, motion)
│                            #    + base, fonte Geist e variáveis de tema (claro/escuro)
│  ├─ main.jsx, App.jsx      # entrypoint + alternador dos exemplos
│  ├─ lib/
│  │  ├─ cn.js               # helper de classes
│  │  ├─ catalog.js          # ⭐ QUANDO USAR CADA COMPONENTE (leia este primeiro)
│  │  └─ tokens.js           # tokens em formato de dados (para a doc Foundations)
│  ├─ components/ui/         # ⭐ A BIBLIOTECA (design system)
│  │  ├─ index.js            #    barrel de exportação
│  │  ├─ primitives.jsx      #    Container, Section, Eyebrow, SectionHeader, Stars
│  │  ├─ Typography.jsx      #    Display, Heading, Text, Code, Kbd, Link
│  │  ├─ Button.jsx          #    Button (+ variantes shiny) e ButtonIconBadge
│  │  ├─ Badge.jsx, Card.jsx, Input.jsx
│  │  ├─ Select.jsx, SegmentedControl.jsx
│  │  ├─ Testimonial.jsx     #    TestimonialCard e VideoTestimonialCard
│  │  ├─ Pricing.jsx, Faq.jsx, Stats.jsx
│  │  ├─ Navbar.jsx, Footer.jsx, ThemeToggle.jsx
│  │  ├─ Marquee.jsx         #    carrossel automático (loop infinito)
│  │  └─ FadeIn, HoverHeadline, MembersPortalMockup, SolutionShowcase
│  └─ examples/              # exemplos de uso (NÃO fazem parte da biblioteca)
│     ├─ data.js             #    conteúdo de exemplo
│     ├─ Foundations.jsx     #    documentação dos tokens (specimens ao vivo)
│     ├─ Showcase.jsx        #    galeria de componentes
│     ├─ LandingPage.jsx     #    landing montada com a biblioteca
│     ├─ DashboardShell.jsx  #    shell do painel: barra lateral, topo, rotas
│     └─ dashboard/          #    telas do painel (só conteúdo; o cromo é do shell)
│        ├─ Overview.jsx     #      teste de pressão: densidade e leitura
│        └─ SalesReport.jsx  #      teste de pressão: filtro, comparação, agregação
```

## Foundations (tokens)

Tokens nomeados no bloco `@theme` de `src/index.css`, documentados ao vivo na aba
**Foundations**. Na Tailwind v4 não existe mais `tailwind.config.js`: os tokens são
CSS variables (`--color-*`, `--text-*`, `--radius-*`, `--shadow-*`…), o que os torna
consumíveis tanto pelos utilitários quanto por CSS puro.

- **Tipografia** — fonte Geist; escala nomeada de `display-2xl` (72px) a `caption`
  (12px), cada nível com peso, entrelinha e *tracking* calibrados. Use os primitivos
  `Display`, `Heading`, `Text` em vez de classes soltas.
- **Cor** — escala neutra (`neutral-0…950`), acento `emerald-50…950` e **tokens
  semânticos temáveis** (`ink`, `body`, `mute`, `hairline`, `surface`, `canvas`,
  `inverse`) que trocam entre claro/escuro via CSS variables em `src/index.css`.
- **Gráfico** — paleta categórica `--chart-1..3` em ordem fixa, com passos próprios
  para cada tema. Validada sob simulação de daltonismo (pior separação ΔE 9.2 no
  claro, 9.4 no escuro). A cor segue a entidade, nunca o ranking; uma quarta série
  vira "Outros" ou facetas, nunca um matiz gerado. Ver §3.4 do `DESIGN.md`.
- **Espaçamento** — base de 4px + tokens de layout (`section`, `gutter`).
- **Raio** — `xs` (4) · `sm` (8) · `md` (12) · `lg` (16) · `xl` (24) · `2xl` (32) · `full`.
- **Elevação** — `shadow-xs…xl`, sombras calibradas por hierarquia.
- **Motion** — durações (`fast/normal/slow/slower`) e easings (`out-soft`, `in-out-soft`).
- **Densidade** — os tokens são calibrados para a landing. Para dashboards e
  telas internas, aplique a classe `ds-app` no elemento raiz do shell: ela
  reaponta a escala de raio para valores de UI sem alterar nenhum componente.
- **Breakpoints** — `sm 640 · md 768 · lg 1024 · xl 1280 · 2xl 1440`.

## Tema claro / escuro

Os tokens semânticos de cor são CSS variables definidas em `:root` (claro) e `.dark`
(escuro). O componente `ThemeToggle` (hook `useTheme`) alterna a classe `dark` em
`<html>` e persiste em `localStorage`; um script no `index.html` aplica o tema antes
da primeira pintura para evitar flash.

## Usando a biblioteca

Tudo é importado do barrel `components/ui`:

```jsx
import { Button, Card, TestimonialCard, PricingCard } from './components/ui'

<Button variant="primary">Começar agora</Button>
<Button variant="secondary">Ver as soluções</Button>
<Card variant="premium">…</Card>
```

### Por onde começar

**`src/lib/catalog.js` é a fonte única de "o que existe e quando usar".** A tabela
abaixo é um resumo; o catálogo tem, para cada um dos componentes exportados, o
escopo (landing / aplicação / ambos), as props, um **quando usar** e um **evite**
que sempre aponta a alternativa. Ele também traz duas listas curtas:

- **`decisoes`** — o índice "preciso de X → use Y", cobrindo os pares que se
  confundem (`SegmentedControl` vs `Select`, `MetricCard` vs `Stats`, badge de
  estado vs de identidade, preset vs intervalo de datas).
- **`regras`** — o que não pertence a um componente só e é o que mais aparece
  quebrado em código gerado sem contexto (escopo `.ds-app` antes de `className`,
  o `cn` não resolve conflito de classes, Phosphor não tem `strokeWidth`, cor de
  gráfico segue a entidade e não o ranking, nunca eixo duplo).

A aba **Componentes** é montada a partir desse arquivo, então página e catálogo
não têm como divergir.

### Componentes principais

| Componente | Descrição |
| :--- | :--- |
| `Display` / `Heading` / `Text` | Primitivos de tipografia — encapsulam a escala nomeada. `Code`, `Kbd`, `Link` completam. |
| `Button` | Pílula. Variantes: `primary`, `secondary`, `ghost`, `shiny`, `shiny-brand`. Tamanhos: `sm/md/lg`. `primary` e `secondary` adaptam-se ao tema. |
| `ButtonIconBadge` | CTA shiny com ícone à direita que desliza no hover. |
| `Badge` | Rótulo compacto. Marca: `emerald`, `soft`, `neutral`. Estado: `success`, `warning`, `danger`, `info`. |
| `Breadcrumbs` | Trilha de navegação: `items` com `label` e `href`/`onClick`; o último vira texto com `aria-current`. |
| `Card` / `FeatureIconCard` / `MediaCard` | Superfícies `flat` e `premium`; card com ícone e card com imagem. |
| `Input` / `Field` | Campo com foco esmeralda. `shape`: `auto` (segue o contexto) · `pill` · `soft`; `icon` para ícone à esquerda. A caixa do rótulo segue o escopo (versalete na landing, minúscula no app). |
| `Select` | `<select>` nativo com a casca do sistema — mesma altura/raio/padding do `Input`, para alinhar numa barra de filtros. |
| `SegmentedControl` | `options` + `value` + `onChange`. Escolha única entre 2–4 opções curtas, todas visíveis; acima disso use `Select`. |
| `TestimonialCard` / `VideoTestimonialCard` | Depoimentos em texto e em vídeo. |
| `PricingCard` | Plano; `featured` destaca com anel esmeralda + escala. |
| `Faq` | Acordeão em cards, acessível e animado. |
| `Stats` | Grade de métricas (`columns`, `size`, `dark` para fundo escuro). |
| `Table` | Tabela dirigida por dados: `columns` (com `align`, `numeric`, `render`, `renderFooter`, `sortable`, `sortValue`) + `rows` + `footer` (linha de total em `<tfoot>`) + `defaultSort`. Ordenação por clique no cabeçalho, interna por padrão e controlável com `sort`/`onSortChange`. |
| `DateInput` / `DateRangeField` | Data nativa com a casca do sistema. No par, as pontas se travam uma na outra: não dá para escolher um fim antes do começo. |
| `MetricCard` | Quadrante de número: `label`, `value`, `delta` (número com sinal), `higherIsBetter`, `comparison`. A seta vem do sinal do delta; a cor, de `delta × higherIsBetter` — reembolso que sobe fica vermelho **com a seta para cima**. |
| `SidebarNav` | Navegação lateral de aplicação: grupos com subtítulo, submenus, colapso para faixa de ícones. |
| `Logo` | `variant`: `full` ou `symbol` (só o símbolo). |
| `Navbar` / `Footer` | Cabeçalho e rodapé (logo com inversão automática no escuro). |
| `Marquee` | Carrossel automático em loop infinito (logos, depoimentos…). |
| `FadeIn` / `HoverHeadline` / `SolutionShowcase` / `MembersPortalMockup` | Efeitos e blocos de composição usados na landing. |
| `ThemeToggle` / `useTheme` | Alternador de tema claro/escuro. |

## Notas

- Ícones: [`@phosphor-icons/react`](https://phosphoricons.com). São desenhados em
  `fill` (não em traço): a espessura vem da prop `weight` — `thin`, `light`,
  `regular`, `bold`, `fill` e `duotone`. O padrão do sistema é `regular` — o
  contorno puro é o que conversa com uma página construída sobre linhas de 1px.
  `fill` fica para play, estrelas e estados ativos; `bold` para ícone pequeno
  dentro de botão. A utility `icon-duotone` (segundo tom em esmeralda) existe
  para blocos de destaque isolados, não para cards e selos.
- As imagens e wordmarks de logo nos exemplos são **placeholders** (Unsplash / texto)
  — troque pelos ativos reais.
- O design system anterior em HTML/CSS está na pasta irmã `../design-system/`.
