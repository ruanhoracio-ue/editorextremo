import { useState } from 'react'
import { DownloadSimple } from '@phosphor-icons/react'
import Foundations from './examples/Foundations'
import Showcase from './examples/Showcase'
import LandingPage from './examples/LandingPage'
import DashboardShell from './examples/DashboardShell'
import { ThemeToggle } from './components/ui'
import { cn } from './lib/cn'
import designDoc from '../DESIGN.md?raw'

/** Baixa o DESIGN.md (importado como texto no build — sempre em sincronia). */
function downloadDesignDoc() {
  const blob = new Blob([designDoc], { type: 'text/markdown;charset=utf-8' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = 'DESIGN.md'
  a.click()
  URL.revokeObjectURL(url)
}

/**
 * App — alterna entre Foundations (tokens), Showcase (componentes) e a Landing
 * de exemplo. Showcase e Landing são demonstrações de uso da biblioteca.
 */
const views = [
  { id: 'foundations', label: 'Foundations' },
  { id: 'showcase', label: 'Componentes' },
  { id: 'landing', label: 'Landing (exemplo)' },
  { id: 'dashboard', label: 'Dashboard (teste)' },
]

const screens = {
  foundations: Foundations,
  showcase: Showcase,
  landing: LandingPage,
  dashboard: DashboardShell,
}

export default function App() {
  const [view, setView] = useState('foundations')

  return (
    <div>
      <svg className="pointer-events-none absolute h-0 w-0">
        <defs>
          <linearGradient id="brand-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop stopColor="var(--brand-grad-from)" offset="0%" />
            <stop stopColor="var(--brand-grad-to)" offset="100%" />
          </linearGradient>
        </defs>
      </svg>
      {/* Alternador flutuante de exemplos (não faz parte da biblioteca) */}
      <div className="fixed bottom-5 left-1/2 z-toast flex -translate-x-1/2 items-center gap-1 rounded-full border border-hairline bg-surface/90 p-1 shadow-soft backdrop-blur-sm">
        {views.map((v) => (
          <button
            key={v.id}
            onClick={() => setView(v.id)}
            className={cn(
              'rounded-full px-4 py-1.5 text-sm font-medium transition-colors',
              view === v.id ? 'bg-inverse text-on-inverse' : 'text-body hover:text-ink',
            )}
          >
            {v.label}
          </button>
        ))}
        <span className="mx-0.5 h-5 w-px bg-hairline" />
        <button
          type="button"
          onClick={downloadDesignDoc}
          aria-label="Baixar DESIGN.md"
          title="Baixar DESIGN.md"
          className="inline-flex h-8 w-8 items-center justify-center rounded-full text-body transition-colors hover:text-ink"
        >
          <DownloadSimple size={16} />
        </button>
        <ThemeToggle className="h-8 w-8 border-0" />
      </div>

      {(() => {
        const Screen = screens[view]
        return <Screen />
      })()}
    </div>
  )
}
