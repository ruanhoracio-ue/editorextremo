import { useState } from 'react'
import { ArrowRight, MagnifyingGlass, Check, X, House, ChartLine, Users, Gear } from '@phosphor-icons/react'
import {
  Container,
  Eyebrow,
  SectionHeader,
  Button,
  ButtonIconBadge,
  Badge,
  Card,
  FeatureIconCard,
  MediaCard,
  MetricCard,
  Field,
  Input,
  Select,
  SegmentedControl,
  DateRangeField,
  Table,
  Breadcrumbs,
  SidebarNav,
  Logo,
  ThemeToggle,
  TestimonialCard,
  VideoTestimonialCard,
  PricingCard,
  SolutionShowcase,
  Faq,
  Stats,
  Marquee,
  HoverHeadline,
  FadeIn,
  DotGrid,
  VideoLightbox,
  Navbar,
  Footer,
  Text,
  Heading,
  Code,
  Kbd,
  Link,
} from '../components/ui'
import { categorias, componentes, decisoes, regras, ESCOPOS } from '../lib/catalog'
import {
  solutions,
  audiences,
  textTestimonials,
  videoTestimonials,
  plans,
  faqs,
  stats,
  clientLogos,
  navLinks,
  footerLinks,
} from './data'

/**
 * Showcase — a biblioteca em uso, organizada por decisão.
 *
 * A galeria antiga mostrava como cada peça É. O que não dá para inferir
 * olhando é QUANDO ela é a escolha certa — e é justamente isso que falta a
 * quem chega sem ter escrito o sistema, pessoa ou agente. Então a página é
 * montada a partir de `lib/catalog.js`: primeiro o índice de decisão e as
 * regras gerais, depois cada componente com escopo, props, "quando usar" e
 * "evite", com a demonstração ao vivo logo abaixo.
 *
 * Nenhuma demonstração foi removida na reorganização; as que faltavam para os
 * componentes de aplicação foram acrescentadas.
 */

/* ── Blocos de apoio ──────────────────────────────────────────────────── */

/**
 * O catálogo é um arquivo de dados que também é lido como texto no editor, e
 * lá `crase` é a convenção de código. Aqui ela vira `<code>` de verdade — sem
 * isso os crases apareceriam crus na tela.
 *
 * Deliberadamente é só isso: um mini-parser de markdown completo num arquivo
 * de galeria seria uma dependência escondida.
 */
function Txt({ children }) {
  if (typeof children !== 'string') return children
  return children.split(/(`[^`]+`)/g).map((parte, i) =>
    parte.startsWith('`') && parte.endsWith('`') ? (
      <Code key={i}>{parte.slice(1, -1)}</Code>
    ) : (
      parte
    ),
  )
}

function Secao({ id, titulo, resumo, children }) {
  return (
    <section id={id} className="scroll-mt-24 border-t border-hairline pt-12">
      <Heading level={2} className="text-heading-lg">
        {titulo}
      </Heading>
      {resumo && (
        <Text tone="body" className="mt-2 max-w-prose">
          {resumo}
        </Text>
      )}
      <div className="mt-8 flex flex-col gap-6">{children}</div>
    </section>
  )
}

const chipEscopo = {
  landing: 'bg-elevated text-mute',
  app: 'bg-emerald-soft text-emerald-deep',
  ambos: 'bg-elevated text-body',
}

function Spec({ c, demo }) {
  return (
    <div className="overflow-hidden rounded-lg border border-hairline bg-surface">
      <div className="flex flex-col gap-3 p-5">
        <div className="flex flex-wrap items-center gap-2">
          <code className="font-mono text-label-lg font-semibold text-ink">{c.nome}</code>
          <span
            className={`rounded-full px-2 py-0.5 text-[11px] font-semibold ${chipEscopo[c.escopo ?? 'ambos']}`}
            title={ESCOPOS[c.escopo ?? 'ambos'].desc}
          >
            {ESCOPOS[c.escopo ?? 'ambos'].label}
          </span>
        </div>

        <p className="text-sm text-body">
          <Txt>{c.proposito}</Txt>
        </p>

        {c.props?.length > 0 && (
          <dl className="flex flex-col gap-1 border-l-2 border-hairline pl-3">
            {c.props.map((p) => (
              <div key={p.nome} className="flex flex-wrap gap-x-2 text-caption">
                <dt className="font-mono font-medium text-ink">{p.nome}</dt>
                {p.valores && (
                  <dd className="text-mute">
                    <Txt>{p.valores}</Txt>
                  </dd>
                )}
              </div>
            ))}
          </dl>
        )}

        {c.quandoUsar && (
          <p className="flex gap-2 text-sm">
            <Check size={15} weight="bold" className="mt-0.5 shrink-0 text-emerald-deep" aria-hidden="true" />
            <span className="text-body">
              <strong className="font-semibold text-ink">Quando usar. </strong>
              <Txt>{c.quandoUsar}</Txt>
            </span>
          </p>
        )}

        {/* `evite` sempre aponta a saída. Regra que só proíbe deixa quem lê
            sem alternativa — e é aí que ele inventa a própria. */}
        {c.evite && (
          <p className="flex gap-2 text-sm">
            <X size={15} weight="bold" className="mt-0.5 shrink-0 text-danger" aria-hidden="true" />
            <span className="text-body">
              <strong className="font-semibold text-ink">Evite. </strong>
              <Txt>{c.evite}</Txt>
            </span>
          </p>
        )}

        {c.nota && (
          <p className="text-caption text-mute">
            <Txt>{c.nota}</Txt>
          </p>
        )}
        {c.aberto && (
          <p className="text-caption text-mute">
            <span className="font-semibold">Em aberto. </span>
            <Txt>{c.aberto}</Txt>
          </p>
        )}
      </div>

      {demo && <div className="border-t border-hairline bg-canvas p-5">{demo}</div>}
    </div>
  )
}

/* ── Demonstrações que precisam de estado ─────────────────────────────── */

function DemoSegmented() {
  const [v, setV] = useState('14d')
  return (
    <SegmentedControl
      ariaLabel="Período"
      value={v}
      onChange={setV}
      options={[
        { value: '7d', label: '7 dias' },
        { value: '14d', label: '14 dias' },
        { value: '30d', label: '30 dias' },
      ]}
    />
  )
}

function DemoIntervalo() {
  const [r, setR] = useState({ inicio: '2026-07-14', fim: '2026-07-27' })
  return <DateRangeField value={r} onChange={setR} min="2026-01-01" max="2026-12-31" />
}

const linhasDemo = [
  { id: 1, aluno: 'Marina Oliveira', plano: 'Black', valor: 4980, dias: 0 },
  { id: 2, aluno: 'Juliana Prado', plano: 'Mind', valor: 9800, dias: 1 },
  { id: 3, aluno: 'Rafael Santos', plano: 'Plus', valor: 1240, dias: 2 },
]
const brl = (v) => v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', maximumFractionDigits: 0 })

function DemoTabela() {
  return (
    <div className="overflow-hidden rounded-md border border-hairline bg-surface">
      <Table
        rows={linhasDemo}
        getRowKey={(r) => r.id}
        defaultSort={{ key: 'dias', dir: 'asc' }}
        footer={{ aluno: 'Total', valor: linhasDemo.reduce((a, r) => a + r.valor, 0) }}
        columns={[
          { key: 'aluno', header: 'Aluno', sortable: true },
          { key: 'plano', header: 'Plano', sortable: true },
          {
            key: 'valor',
            header: 'Valor',
            numeric: true,
            align: 'right',
            sortable: true,
            render: (r) => brl(r.valor),
            renderFooter: (f) => brl(f.valor),
          },
          {
            key: 'dias',
            header: 'Quando',
            align: 'right',
            sortable: true,
            render: (r) => (r.dias === 0 ? 'Hoje' : r.dias === 1 ? 'Ontem' : `${r.dias} dias atrás`),
          },
        ]}
      />
    </div>
  )
}

function DemoSidebar() {
  const [ativo, setAtivo] = useState('relatorios-vendas')
  const [recolhido, setRecolhido] = useState(false)
  return (
    <div className="ds-app flex h-80 overflow-hidden rounded-md border border-hairline">
      <SidebarNav
        active={ativo}
        onSelect={setAtivo}
        collapsed={recolhido}
        onToggleCollapsed={() => setRecolhido((v) => !v)}
        header={({ collapsed }) => (
          <Logo variant={collapsed ? 'symbol' : 'full'} className={collapsed ? 'h-6 w-6' : 'h-5'} />
        )}
        groups={[
          {
            items: [
              { key: 'visao', icon: House, label: 'Visão geral' },
              {
                key: 'relatorios',
                icon: ChartLine,
                label: 'Relatórios',
                items: [
                  { key: 'relatorios-vendas', label: 'Vendas por período' },
                  { key: 'relatorios-coortes', label: 'Coortes' },
                ],
              },
            ],
          },
          {
            label: 'Gestão',
            items: [
              { key: 'alunos', icon: Users, label: 'Alunos', badge: '1.284' },
              { key: 'config', icon: Gear, label: 'Configurações' },
            ],
          },
        ]}
      />
      <div className="flex flex-1 items-center justify-center bg-canvas">
        <Text size="sm" tone="mute">
          Passe o mouse na barra para ver o gatilho de recolher
        </Text>
      </div>
    </div>
  )
}

/* ── Demonstrações estáticas, por nome de componente ──────────────────── */

const demos = {
  Container: (
    <div className="flex flex-col gap-2">
      {[
        ['default', '1200px', 'w-full max-w-[1200px]'],
        ['wide', '1360px', 'w-full max-w-[1360px]'],
        ['fluid', 'sem teto', 'w-full'],
      ].map(([nome, px, cls]) => (
        <div key={nome} className="flex items-center gap-3">
          <span className="w-16 shrink-0 font-mono text-caption text-mute">{nome}</span>
          <div className={`h-3 rounded-xs bg-emerald/25 ${cls}`} style={{ maxWidth: `${nome === 'default' ? 60 : nome === 'wide' ? 78 : 100}%` }} />
          <span className="shrink-0 text-caption text-faint">{px}</span>
        </div>
      ))}
    </div>
  ),

  SectionHeader: (
    <SectionHeader
      eyebrow="Para quem é"
      title={
        <>
          Feito para quem quer <HoverHeadline text="vender mais com IA" />
        </>
      }
      description="Passe o mouse sobre o trecho em gradiente para ver o brilho varrer o texto."
    />
  ),

  Navbar: (
    <div className="overflow-hidden rounded-md border border-hairline">
      <Navbar links={navLinks} />
    </div>
  ),

  Footer: (
    <div className="overflow-hidden rounded-md border border-hairline">
      <Footer links={footerLinks} />
    </div>
  ),

  Logo: (
    <div className="flex items-center gap-8">
      <div className="flex flex-col items-center gap-2">
        <Logo variant="full" className="h-6" />
        <span className="font-mono text-caption text-mute">full</span>
      </div>
      <div className="flex flex-col items-center gap-2">
        <Logo variant="symbol" className="h-8 w-8" />
        <span className="font-mono text-caption text-mute">symbol</span>
      </div>
    </div>
  ),

  Heading: (
    <div className="flex flex-col gap-2">
      <Heading level={1}>Título de página (level 1)</Heading>
      <Heading level={2}>Título de seção (level 2)</Heading>
      <Heading level={3}>Subtítulo (level 3)</Heading>
      <Heading level={4}>Título de card (level 4)</Heading>
    </div>
  ),

  Text: (
    <div className="flex flex-col gap-2">
      <Text size="lg">Parágrafo destacado (size lg)</Text>
      <Text>Corpo padrão (size md, tone body)</Text>
      <Text size="sm" tone="mute">
        Texto de apoio (size sm, tone mute)
      </Text>
    </div>
  ),

  Eyebrow: <Eyebrow>Design System</Eyebrow>,

  HoverHeadline: (
    <h3 className="text-heading-lg text-ink">
      Multiplicar vendas com <HoverHeadline text="IA pronta para usar" />
    </h3>
  ),

  Link: (
    <Text>
      Um parágrafo com um <Link href="#">link inline</Link>, um <Code>trecho de código</Code> e a
      tecla <Kbd>Esc</Kbd>.
    </Text>
  ),

  Button: (
    <div className="flex flex-col gap-6">
      {[
        ['shiny — ação primária', <Button variant="shiny">Começar agora</Button>, <Button variant="shiny" icon={<ArrowRight size={16} />}>Começar agora</Button>],
        ['shiny-brand', <Button variant="shiny-brand">Falar com IAgo</Button>, <Button variant="shiny-brand" icon={<ArrowRight size={16} />}>Falar com IAgo</Button>],
        ['secondary — no hover ganha o anel giratório; no escuro preenche de branco', <Button variant="secondary">Ver soluções</Button>, <Button variant="secondary" icon={<ArrowRight size={16} />}>Ver soluções</Button>],
        ['ghost — ação terciária', <Button variant="ghost">Entrar</Button>, <Button variant="ghost" icon={<ArrowRight size={16} />}>Entrar</Button>],
      ].map(([rotulo, a, b]) => (
        <div key={rotulo} className="flex flex-col gap-2">
          <span className="text-caption text-mute">{rotulo}</span>
          <div className="flex flex-wrap items-center gap-3">
            {a}
            {b}
          </div>
        </div>
      ))}
      <div className="flex flex-col gap-2">
        <span className="text-caption text-mute">tamanhos</span>
        <div className="flex flex-wrap items-center gap-3">
          <Button variant="shiny" size="sm">
            sm
          </Button>
          <Button variant="shiny" size="md">
            md
          </Button>
          <Button variant="shiny" size="lg">
            lg
          </Button>
          <span className="ds-app inline-flex">
            <Button variant="secondary" size="field">
              field
            </Button>
          </span>
        </div>
      </div>
    </div>
  ),

  ButtonIconBadge: <ButtonIconBadge icon={<ArrowRight size={16} />}>Quero fazer parte</ButtonIconBadge>,

  Field: (
    <div className="grid max-w-2xl grid-cols-1 gap-4 sm:grid-cols-2">
      <Field label="E-mail corporativo">
        <Input type="email" placeholder="voce@empresa.com.br" />
      </Field>
      <div className="ds-app">
        <Field label="Mesmo campo dentro de .ds-app">
          <Input placeholder="rótulo em caixa normal" />
        </Field>
      </div>
    </div>
  ),

  Input: (
    <div className="flex max-w-md flex-col gap-3">
      <Input placeholder="shape auto (pílula fora do .ds-app)" />
      <Input shape="soft" placeholder="shape soft" />
      <Input shape="pill" icon={<MagnifyingGlass size={16} />} placeholder="com icon, shape pill" />
    </div>
  ),

  Select: (
    <div className="ds-app w-56">
      <Select defaultValue="todos" aria-label="Plano">
        <option value="todos">Todos os planos</option>
        <option value="black">Black</option>
        <option value="plus">Plus</option>
      </Select>
    </div>
  ),

  SegmentedControl: <DemoSegmented />,
  DateRangeField: <div className="ds-app"><DemoIntervalo /></div>,

  Table: <DemoTabela />,

  MetricCard: (
    <div className="ds-app grid grid-cols-1 gap-4 sm:grid-cols-3">
      <MetricCard label="Receita no mês" value="R$ 284.320" delta={12.4} comparison="vs. mês anterior" />
      <MetricCard label="Taxa de conversão" value="3,42%" delta={-0.3} comparison="vs. mês anterior" />
      <MetricCard
        label="Reembolsos"
        value="R$ 6.220"
        delta={24.9}
        higherIsBetter={false}
        comparison="vs. mês anterior"
      />
    </div>
  ),

  Stats: <Stats items={stats} className="max-w-lg" />,

  Badge: (
    <div className="flex flex-col gap-4">
      <div className="flex flex-col gap-2">
        <span className="text-caption text-mute">marca</span>
        <div className="flex flex-wrap items-center gap-3">
          <Badge tone="emerald">Sólida</Badge>
          <Badge tone="soft">Suave</Badge>
          <Badge tone="neutral">Neutra</Badge>
        </div>
      </div>
      <div className="flex flex-col gap-2">
        <span className="text-caption text-mute">estado — troque o tema para ver o par soft/deep virar</span>
        <div className="flex flex-wrap items-center gap-3">
          <Badge tone="success">Ativo</Badge>
          <Badge tone="warning">Pendente</Badge>
          <Badge tone="danger">Cancelado</Badge>
          <Badge tone="info">Em análise</Badge>
        </div>
      </div>
    </div>
  ),

  SidebarNav: <DemoSidebar />,

  Breadcrumbs: (
    <Breadcrumbs
      items={[
        { label: 'Painel', href: '#' },
        { label: 'Relatórios', href: '#' },
        { label: 'Vendas por período' },
      ]}
    />
  ),

  ThemeToggle: (
    <div className="flex items-center gap-3">
      <ThemeToggle />
      <Text size="sm" tone="mute">
        Alterna a classe <Code>dark</Code> em <Code>&lt;html&gt;</Code>
      </Text>
    </div>
  ),

  Card: (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
      <Card>
        <Badge tone="neutral">Flat</Badge>
        <h3 className="mt-3 text-heading-sm text-ink">Superfície de sistema</h3>
        <p className="mt-1.5 text-sm text-body">
          Passe o cursor: a borda acende no ponto sob o mouse.
        </p>
      </Card>
      <Card variant="premium">
        <Badge tone="soft">Premium</Badge>
        <h3 className="mt-3 text-heading-sm text-ink">Superfície de marketing</h3>
        <p className="mt-1.5 text-sm text-body">
          Borda acende <em>e</em> o brilho interno difuso acompanha o cursor.
        </p>
      </Card>
    </div>
  ),

  FeatureIconCard: (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {audiences.slice(0, 3).map((a) => (
        <FeatureIconCard key={a.title} premium {...a} />
      ))}
    </div>
  ),

  MediaCard: (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
      <MediaCard
        image="https://images.unsplash.com/photo-1551836022-d5d88e9218df?auto=format&fit=crop&w=800&q=80"
        imageAlt="Equipe em treinamento"
        badge="Novo"
        eyebrow="Aula magna"
        title="Estratégia de Escala 2026"
        description="Aula de implementação prática com casos de sucesso reais."
      />
      <MediaCard
        image="https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=800&q=80"
        imageAlt="Equipe colaborando"
        badge="Ao vivo"
        eyebrow="Programa"
        title="Aceleração de Vendas"
        description="Metodologias comprovadas para transformar visitantes em clientes."
      />
      <MediaCard
        image="https://images.unsplash.com/photo-1543269865-cbf427effbad?auto=format&fit=crop&w=800&q=80"
        imageAlt="Networking de empresários"
        eyebrow="Comunidade"
        title="Networking de Elite"
        description="Conecte-se com quem já escalou operações de verdade."
      />
    </div>
  ),

  TestimonialCard: (
    <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
      {textTestimonials.map((t) => (
        <TestimonialCard key={t.name} {...t} />
      ))}
    </div>
  ),

  VideoTestimonialCard: (
    <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
      {videoTestimonials.map((t) => (
        <VideoTestimonialCard key={t.name} {...t} />
      ))}
    </div>
  ),

  PricingCard: (
    <div className="grid grid-cols-1 items-start gap-6 md:grid-cols-3">
      {plans.map((p) => (
        <PricingCard key={p.name} {...p} />
      ))}
    </div>
  ),

  SolutionShowcase: <SolutionShowcase solution={solutions[0]} />,

  Faq: <Faq items={faqs} className="mx-0 max-w-3xl" />,

  Marquee: (
    <Marquee duration={30}>
      {clientLogos.map((logo) => (
        <span
          key={logo}
          className="cursor-default select-none text-2xl font-semibold tracking-tight text-mute transition-colors hover:text-ink"
        >
          {logo}
        </span>
      ))}
    </Marquee>
  ),

  VideoLightbox: (
    <div className="mx-auto max-w-2xl">
      <VideoLightbox videoId="iLgfoYiAVT0" />
    </div>
  ),

  FadeIn: (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
      {[0, 120, 240].map((delay) => (
        <FadeIn key={delay} delay={delay}>
          <Card variant="premium">
            <p className="text-sm text-body">delay de {delay}ms</p>
          </Card>
        </FadeIn>
      ))}
    </div>
  ),

  DotGrid: (
    <div className="relative h-56 overflow-hidden rounded-md border border-hairline">
      <DotGrid />
    </div>
  ),

  useSpotlight: (
    <Card>
      <p className="text-sm text-body">
        O brilho de borda deste card vem daqui — um anel de 1px mascarado, desenhado nas coordenadas
        que o hook publica. Sem sombra externa: no sistema a superfície é definida pelo contorno.
      </p>
    </Card>
  ),
}

/* ── Página ───────────────────────────────────────────────────────────── */

export default function Showcase() {
  return (
    <div className="bg-canvas">
      <Container className="py-16">
        <header className="max-w-3xl">
          <Eyebrow>Design System · React + Tailwind</Eyebrow>
          <h1 className="mt-3 text-display-lg text-ink">Biblioteca de componentes</h1>
          <Text size="xl" tone="body" className="mt-5">
            Tudo vem do barrel <Code>src/components/ui</Code>. Esta página é montada a partir de{' '}
            <Code>src/lib/catalog.js</Code>, que guarda a decisão — quando cada componente é a
            escolha certa e quando é a errada. Se for ler um arquivo só, leia aquele.
          </Text>
          {/* A tira de cores que ficava aqui era um recorte de sete tokens. A
              aba Foundations mostra as escalas inteiras, os semânticos, os
              pares soft/deep e a paleta de gráfico — manter as duas seria
              criar uma segunda fonte, menos completa, que uma hora discorda. */}
          <Text size="sm" tone="mute" className="mt-4">
            Cor, tipografia, espaçamento, raio, elevação, motion e o escopo{' '}
            <Code>.ds-app</Code> ficam na aba <strong className="font-medium text-body">Foundations</strong>.
          </Text>
        </header>

        {/* ── ÍNDICE DE DECISÃO ────────────────────────────────────────── */}
        <section id="decisao" className="mt-14 scroll-mt-24">
          <Heading level={2} className="text-heading-lg">
            Qual eu uso?
          </Heading>
          <Text tone="body" className="mt-2 max-w-prose">
            Os pares que se confundem, resolvidos. Comece por aqui.
          </Text>
          <div className="mt-6 overflow-hidden rounded-lg border border-hairline bg-surface">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-hairline-soft">
                  <th scope="col" className="px-5 py-3 text-left font-semibold text-mute">
                    Preciso de
                  </th>
                  <th scope="col" className="px-5 py-3 text-left font-semibold text-mute">
                    Use
                  </th>
                  <th scope="col" className="px-5 py-3 text-left font-semibold text-mute">
                    Quando
                  </th>
                </tr>
              </thead>
              <tbody>
                {decisoes.map((d) => (
                  <tr key={d.preciso} className="border-b border-hairline-soft last:border-0">
                    <td className="px-5 py-3 font-medium text-body">{d.preciso}</td>
                    <td className="px-5 py-3">
                      <code className="font-mono text-caption text-emerald-deep">{d.use}</code>
                    </td>
                    <td className="px-5 py-3 text-mute">
                      <Txt>{d.quando}</Txt>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        {/* ── REGRAS GERAIS ────────────────────────────────────────────── */}
        <section id="regras" className="mt-14 scroll-mt-24">
          <Heading level={2} className="text-heading-lg">
            Regras que não pertencem a um componente só
          </Heading>
          <Text tone="body" className="mt-2 max-w-prose">
            São as que mais aparecem quebradas em código gerado sem contexto.
          </Text>
          <div className="mt-6 grid grid-cols-1 gap-4 md:grid-cols-2">
            {regras.map((r) => (
              <div key={r.regra} className="rounded-lg border border-hairline bg-surface p-5">
                <div className="text-label-lg font-semibold text-ink">{r.regra}</div>
                <p className="mt-1.5 text-sm text-body">
                  <Txt>{r.detalhe}</Txt>
                </p>
              </div>
            ))}
          </div>
        </section>

        {/* ── CATEGORIAS ───────────────────────────────────────────────── */}
        <div className="mt-16 flex flex-col gap-14">
          {categorias.map((cat) => (
            <Secao key={cat.id} id={cat.id} titulo={cat.label} resumo={cat.resumo}>
              {componentes
                .filter((c) => c.categoria === cat.id)
                .map((c) => (
                  <Spec key={c.nome} c={c} demo={demos[c.nome]} />
                ))}
            </Secao>
          ))}
        </div>
      </Container>
    </div>
  )
}
