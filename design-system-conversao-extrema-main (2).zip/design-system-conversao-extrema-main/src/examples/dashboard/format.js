/** Formatação de moeda compartilhada pelas telas do painel. */
export const brl = (v) =>
  v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', maximumFractionDigits: 0 })
