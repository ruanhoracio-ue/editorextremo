import { DotsThree, Funnel, ArrowRight } from '@phosphor-icons/react'
import {
  Card,
  Badge,
  Button,
  Field,
  Input,
  Heading,
  Table,
  MetricCard,
} from '../../components/ui'
import { cn } from '../../lib/cn'
import { brl } from './format'

/**
 * Overview — a página inicial do painel.
 *
 * Só o conteúdo: cabeçalho (trilha + título) e cromo ficam com o
 * `DashboardShell`, que é quem conhece a árvore de navegação.
 */

/* `delta` é número e `higherIsBetter` marca as métricas em que cair é a boa
   notícia. Antes era um booleano `up` só, fazendo dois trabalhos: direção da
   seta e cor — e quem precisava de vermelho num número que subiu acabava com
   a seta apontando para o lado errado. */
const metrics = [
  { label: 'Receita no mês', value: 'R$ 284.320', delta: 12.4 },
  { label: 'Novos alunos', value: '1.284', delta: 8.1 },
  { label: 'Taxa de conversão', value: '3,42%', delta: -0.3 },
  { label: 'Ticket médio', value: 'R$ 221', delta: 2.7 },
]

/* `valor` é número. Guardar "R$ 4.980" pronto obrigaria a ordenação a
   comparar texto — e por texto R$ 9.800 vem antes de R$ 12.000. */
const rows = [
  { nome: 'Marina Oliveira', plano: 'Black', valor: 4980, status: 'Ativo', dias: 0 },
  { nome: 'Rafael Santos', plano: 'Plus', valor: 1240, status: 'Ativo', dias: 0 },
  { nome: 'Juliana Prado', plano: 'Mind', valor: 9800, status: 'Pendente', dias: 1 },
  { nome: 'Carlos Menezes', plano: 'Plus', valor: 1240, status: 'Ativo', dias: 1 },
  { nome: 'Ana Beatriz', plano: 'Black', valor: 4980, status: 'Cancelado', dias: 2 },
]

/* Numa tabela chamada "vendas recentes", "28/07" obriga o leitor a saber que
   dia é hoje para extrair a única informação que ele quer: há quanto tempo.
   Passando de uma semana o relativo perde a precisão e a data volta. */
const quando = (dias) =>
  dias === 0 ? 'Hoje' : dias === 1 ? 'Ontem' : dias < 7 ? `${dias} dias atrás` : `${dias}d`

const statusTone = { Ativo: 'success', Pendente: 'warning', Cancelado: 'danger' }

const meta = (() => {
  const realizado = 284320
  const alvo = 350000
  const diaDoMes = 27 /* dado de exemplo escolhido para o caso 'atrás do ritmo' */
  const diasNoMes = 31
  const percentual = Math.round((realizado / alvo) * 100)
  const ritmo = Math.round((diaDoMes / diasNoMes) * 100)
  return {
    realizado,
    alvo,
    percentual,
    ritmo,
    diaDoMes,
    diasRestantes: diasNoMes - diaDoMes,
    atrasada: percentual < ritmo,
  }
})()

const colunas = [
  {
    key: 'nome',
    header: 'Aluno',
    sortable: true,
    render: (r) => <span className="font-medium text-ink">{r.nome}</span>,
  },
  { key: 'plano', header: 'Plano', sortable: true },
  { key: 'valor', header: 'Valor', numeric: true, align: 'right', sortable: true, render: (r) => brl(r.valor) },
  {
    key: 'status',
    header: 'Status',
    sortable: true,
    render: (r) => <Badge tone={statusTone[r.status]}>{r.status}</Badge>,
  },
  /* Ordena pelo número de dias, não pelo rótulo: por texto "Ontem" viria
     antes de "Hoje". */
  { key: 'dias', header: 'Quando', align: 'right', sortable: true, render: (r) => quando(r.dias) },
]

export default function Overview() {
  return (
    <>
      {/* MÉTRICAS */}
      {/* RESOLVIDO — o quadrante virou `MetricCard` da biblioteca. As duas
          telas do painel repetiam o mesmo markup, que é a regra que eu mesmo
          escrevi para extrair: só quando uma segunda tela pede o mesmo. */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {metrics.map((m) => (
          <MetricCard key={m.label} {...m} comparison="vs. mês anterior" />
        ))}
      </div>

      <div className="mt-6 grid grid-cols-1 gap-6 xl:grid-cols-[1fr_320px]">
        {/* TABELA */}
        <Card className="p-0">
          <div className="flex items-center justify-between gap-4 border-b border-hairline p-5">
            <Heading level={3}>Vendas recentes</Heading>
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="sm" icon={<Funnel size={14} />}>
                Filtrar
              </Button>
              <button className="flex h-8 w-8 items-center justify-center rounded-md text-mute hover:bg-elevated hover:text-ink">
                <DotsThree size={18} weight="bold" />
              </button>
            </div>
          </div>

          <Table
            columns={colunas}
            rows={rows}
            getRowKey={(r) => r.nome}
            defaultSort={{ key: 'dias', dir: 'asc' }}
          />

          {/* Cinco linhas são uma amostra, e amostra precisa de saída. Sem
              isso o card diz "recentes" e deixa o leitor sem saber se são
              todas as vendas ou o começo de uma lista. */}
          <div className="border-t border-hairline p-3 text-center">
            <Button variant="ghost" size="sm" icon={<ArrowRight size={14} />}>
              Ver todas as vendas
            </Button>
          </div>
        </Card>

        {/* PAINEL LATERAL */}
        <div className="flex flex-col gap-6">
          <Card>
            {/* Medidor, não rosca: é uma razão contra um limite. A pista
                é um passo mais claro da MESMA rampa (emerald-soft), para
                que o estado leia na barra inteira, e o preenchimento
                carrega a severidade — âmbar quando o realizado está
                atrás do ritmo esperado para o dia do mês.

                O número que lidera é o realizado, e o rodapé diz quanto
                falta: num card de meta é o "faltam" que se age, não a
                porcentagem, que a própria barra já comunica. */}
            <div className="flex items-baseline justify-between gap-3">
              <Heading level={4}>Meta do mês</Heading>
              <span
                className={cn(
                  'text-sm font-semibold',
                  meta.atrasada ? 'text-warning-deep' : 'text-emerald-deep',
                )}
              >
                {meta.percentual}%
              </span>
            </div>

            {/* Figuras proporcionais, não tabulares: `tabular-nums` dá a
                todo dígito a largura do zero e afrouxa o número em corpo
                grande. Tabular fica para coluna de tabela. */}
            <div className="mt-3 text-[30px] font-semibold leading-none text-ink">
              {brl(meta.realizado)}
            </div>
            <p className="mt-1.5 text-sm text-mute">de {brl(meta.alvo)}</p>

            <div className="relative mt-5">
              <div
                className={cn(
                  'h-2 w-full overflow-hidden rounded-full',
                  /* A pista acompanha a rampa do preenchimento: âmbar
                     sobre pista esmeralda misturaria dois matizes e o
                     estado deixaria de ler na barra inteira. */
                  meta.atrasada ? 'bg-warning-soft' : 'bg-emerald-soft',
                )}
              >
                <div
                  className={cn(
                    'h-full rounded-full transition-[width] duration-slower ease-out-soft',
                    meta.atrasada ? 'bg-warning' : 'bg-emerald',
                  )}
                  style={{ width: `${meta.percentual}%` }}
                />
              </div>
              {/* Marcador do ritmo esperado — sem ele o card diz onde
                  você está, mas não se isso é bom. */}
              <span
                className="absolute -top-1 h-4 w-px bg-ink/40"
                style={{ left: `${meta.ritmo}%` }}
                aria-hidden="true"
              />
            </div>
            <p className="mt-2 text-caption text-faint">
              Marcador: ritmo esperado para o dia {meta.diaDoMes}
            </p>

            <div className="mt-4 flex items-center justify-between border-t border-hairline pt-3 text-sm">
              <span className="text-mute">Faltam</span>
              <span className="font-semibold text-ink">
                {brl(meta.alvo - meta.realizado)}
                <span className="font-normal text-mute"> · {meta.diasRestantes} dias</span>
              </span>
            </div>
          </Card>

          <Card>
            <Heading level={4}>Convidar time</Heading>
            {/* RESOLVIDO — o Field passou a usar `tracking-label`. */}
            <Field label="E-mail" className="mt-4">
              <Input shape="pill" type="email" placeholder="nome@empresa.com.br" />
            </Field>
            <Button variant="secondary" size="field" className="mt-4 w-full">
              Enviar convite
            </Button>
          </Card>
        </div>
      </div>
    </>
  )
}
