import { useState, useMemo } from 'react'
import {
  Card,
  Badge,
  Button,
  Table,
  Select,
  SegmentedControl,
  DateRangeField,
  MetricCard,
  Heading,
  Text,
} from '../../components/ui'
import { cn } from '../../lib/cn'
import { brl } from './format'

/**
 * SalesReport — Relatórios › Vendas por período.
 *
 * Segundo teste de pressão do painel. A visão geral cobriu densidade e
 * leitura; aqui a pergunta é outra: filtro, comparação e agregação. Como a
 * primeira, é montada com a biblioteca como ela está, e o que faltar fica
 * anotado.
 *
 * Só o conteúdo: cabeçalho e ação de exportar ficam com o `DashboardShell`.
 */

/* Ordem fixa. A cor segue a entidade, nunca o ranking: filtrar um plano não
   pode repintar os que sobraram. */
const planos = [
  { key: 'black', label: 'Black', cor: 'var(--chart-1)', preco: 4980 },
  { key: 'plus', label: 'Plus', cor: 'var(--chart-2)', preco: 1240 },
  { key: 'mind', label: 'Mind', cor: 'var(--chart-3)', preco: 9800 },
]

const PERIODOS = [
  { value: 7, label: '7 dias' },
  { value: 14, label: '14 dias' },
  { value: 30, label: '30 dias' },
]

/**
 * 60 dias sintéticos — o dobro da maior janela, porque cada indicador é
 * comparado com o período imediatamente anterior de mesmo tamanho. Sem os 60
 * o delta de "30 dias" não teria contra o que ser calculado, e voltaria a ser
 * a string decorativa que era.
 *
 * Determinista de propósito (mulberry32 com semente fixa, não `Math.random`):
 * um exemplo que sorteia números novos a cada carregamento transforma todo
 * screenshot de verificação em ruído.
 */
const serie = (() => {
  let s = 20260727
  const rnd = () => {
    s = (s + 0x6d2b79f5) | 0
    let t = Math.imul(s ^ (s >>> 15), 1 | s)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }

  const fim = new Date(2026, 6, 27)
  const dias = []
  for (let i = 59; i >= 0; i--) {
    const d = new Date(fim)
    d.setDate(d.getDate() - i)
    const fimDeSemana = d.getDay() === 0 || d.getDay() === 6
    /* Fim de semana vende menos e há uma tendência leve de alta ao longo dos
       60 dias. É o que faz a série parecer uma série, e não ruído branco. */
    const peso = (fimDeSemana ? 0.5 : 1) * (0.85 + ((59 - i) / 59) * 0.3)

    const pedidos = {
      black: Math.round((2 + rnd() * 6) * peso),
      plus: Math.round((4 + rnd() * 11) * peso),
      mind: Math.round(rnd() * 2.4 * peso),
    }
    const receita = {}
    const reembolsos = {}
    for (const p of planos) {
      receita[p.key] = pedidos[p.key] * p.preco
      /* Reembolso é raro e proporcional ao volume do plano: a chance por
         pedido põe o total perto de 1,5% da receita, que é a ordem de
         grandeza real. Um exemplo com 7% de reembolso ensinaria o leitor a
         achar normal um número que na prática seria alarme. */
      reembolsos[p.key] = rnd() < 0.015 * pedidos[p.key] ? p.preco : 0
    }

    dias.push({
      /* `iso` é o que ordena e o que filtra. `dia` é só rótulo: ordenar por
         "DD/MM" viraria bagunça na virada do mês (01/07 antes de 30/06). */
      iso: `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`,
      dia: `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}`,
      receita,
      pedidos,
      reembolsos,
    })
  }
  return dias
})()

const PRIMEIRO_DIA = serie[0].iso
const ULTIMO_DIA = serie[serie.length - 1].iso

/** Atalho de N dias terminando no último dia com dado. */
const intervaloDoPreset = (n) => ({ inicio: serie[serie.length - n].iso, fim: ULTIMO_DIA })

/** Soma um campo do dia sobre os planos visíveis. */
const somaDia = (d, campo, visiveis) => visiveis.reduce((a, p) => a + d[campo][p.key], 0)
const somaJanela = (janela, campo, visiveis) =>
  janela.reduce((a, d) => a + somaDia(d, campo, visiveis), 0)

/** Variação percentual; `null` quando não há base — delta sem base é ruído. */
const variacao = (atual, anterior) =>
  anterior > 0 ? ((atual - anterior) / anterior) * 100 : null

/**
 * Escala "bonita": o topo do eixo cai num múltiplo redondo do passo.
 *
 * Antes as linhas ficavam em `maior × {1, .75, .5, .25}` e o rótulo era
 * arredondado à parte — a linha escrita "45k" estava, de fato, em 45,75k. Um
 * eixo que erra sobre a própria posição é pior que não ter eixo.
 */
function escalaBonita(maximo, divisoes = 4) {
  if (maximo <= 0) return { passo: 1, topo: divisoes }
  const bruto = maximo / divisoes
  const magnitude = 10 ** Math.floor(Math.log10(bruto))
  const passo = [1, 2, 2.5, 5, 10].find((m) => m * magnitude >= bruto) * magnitude
  return { passo, topo: passo * divisoes }
}

const emK = (v) =>
  v === 0 ? '0' : `${(v / 1000).toLocaleString('pt-BR', { maximumFractionDigits: 1 })}k`

/**
 * Coluna empilhada em HTML, não SVG: o texto fica no DOM (sem distorção de
 * escala, legível por leitor de tela) e a altura de cada segmento é uma
 * porcentagem — o gráfico acompanha o container sem recalcular viewBox.
 *
 * Segue as regras de marca do guia: marca fina (24px de teto, o resto da
 * faixa é ar), 2px de vão entre segmentos, canto arredondado só na ponta do
 * dado, grade recessiva, e o valor nunca em cima de cada barra — ele aparece
 * no hover.
 */
function ColunaEmpilhada({ dados, visiveis, hoverIdx, setHoverIdx }) {
  const { passo, topo } = escalaBonita(Math.max(...dados.map((d) => somaDia(d, 'receita', visiveis))))
  const linhas = Array.from({ length: 5 }, (_, i) => (4 - i) * passo)

  /* Em 30 dias não cabe um rótulo por coluna. O passo é calculado, não
     `i % 2`, que só funcionava para a janela de 14. */
  const passoRotulo = Math.ceil(dados.length / 8)

  return (
    <div className="relative">
      {/* Grade recessiva. Agora cada linha está exatamente onde o rótulo diz. */}
      <div className="pointer-events-none absolute inset-0 bottom-6 flex flex-col justify-between">
        {linhas.map((v) => (
          <div key={v} className="flex items-center gap-3">
            <span className="w-14 shrink-0 text-right text-caption tabular-nums text-faint">
              {emK(v)}
            </span>
            <span className="h-px flex-1 bg-hairline-soft" />
          </div>
        ))}
      </div>

      <div className="relative flex h-64 items-end gap-1.5 pl-[68px]">
        {dados.map((d, i) => {
          const ativo = hoverIdx === i
          return (
            <div
              key={d.dia}
              className="group/col relative flex h-full flex-1 flex-col justify-end"
              onMouseEnter={() => setHoverIdx(i)}
              onMouseLeave={() => setHoverIdx(null)}
            >
              {/* Alvo de hover maior que a marca: cobre a faixa inteira, não
                  só os 24px pintados. */}
              <span
                className={cn(
                  'absolute inset-x-0 bottom-0 top-0 rounded-sm transition-colors',
                  ativo && 'bg-ink/[0.04]',
                )}
              />
              {visiveis
                .filter((p) => d.receita[p.key] > 0)
                .map((p, k) => (
                  <div
                    key={p.key}
                    /* Teto de 24px: a marca não preenche a faixa, sobra ar.
                       Bloco grosso e saturado lê alto — e, em escala, meio
                       infantil.

                       O vão de 2px vai ACIMA de cada segmento a partir do
                       segundo, para cair entre os segmentos e não entre o
                       último e a linha de base, que precisa ficar colada. */
                    className={cn('relative mx-auto w-full max-w-6', k > 0 && 'mt-0.5')}
                    style={{
                      height: `${(d.receita[p.key] / topo) * 100}%`,
                      background: p.cor,
                      /* Canto arredondado só na ponta do dado (o topo da
                         pilha). A base fica reta porque está ancorada no
                         eixo — arredondar ali descolaria a marca do zero. */
                      borderRadius: k === 0 ? '4px 4px 0 0' : undefined,
                    }}
                  />
                ))}
              <span className="mt-2 block text-center text-caption tabular-nums text-faint">
                {i % passoRotulo === 0 ? d.dia.slice(0, 2) : ''}
              </span>
            </div>
          )
        })}

        {hoverIdx !== null && (
          <div
            className="pointer-events-none absolute -top-2 z-raised rounded-md border border-hairline bg-surface p-3 shadow-md"
            /* O balão fica AO LADO da coluna, nunca em cima dela: centrado no
               cursor ele cobria justamente a marca que está descrevendo. Vira
               para a esquerda na metade direita do gráfico, que é o mesmo
               movimento que impede o corte na borda.

               A faixa de colunas é `100% - 68px` (o eixo ocupa os 68px do
               padding). Medir a fração sobre `100%` cheio empurrava o balão
               para fora — quase uma coluna inteira de erro na ponta direita. */
            style={{
              left: `calc(68px + (100% - 68px) * ${(hoverIdx + 0.5) / dados.length})`,
              transform:
                hoverIdx > dados.length / 2
                  ? 'translateX(calc(-100% - 14px))'
                  : 'translateX(14px)',
            }}
          >
            <div className="mb-1.5 text-caption font-semibold text-ink">{dados[hoverIdx].dia}</div>
            {visiveis.map((p) => (
              <div key={p.key} className="flex items-center gap-2 whitespace-nowrap text-caption">
                <span className="h-2 w-2 shrink-0 rounded-full" style={{ background: p.cor }} />
                <span className="text-mute">{p.label}</span>
                <span className="ml-auto font-medium tabular-nums text-ink">
                  {brl(dados[hoverIdx].receita[p.key])}
                </span>
              </div>
            ))}
            {visiveis.length > 1 && (
              <div className="mt-1.5 flex gap-4 border-t border-hairline pt-1.5 text-caption">
                <span className="text-mute">Total</span>
                <span className="ml-auto font-semibold tabular-nums text-ink">
                  {brl(somaDia(dados[hoverIdx], 'receita', visiveis))}
                </span>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}

/* Zero repetido numa coluna de valores é ruído que o olho tem que pular a
   cada linha. O travessão em `faint` diz "nada aqui" sem disputar atenção
   com os números que importam. */
const valorOuTraco = (v) =>
  v > 0 ? brl(v) : <span className="font-normal text-faint">—</span>

export default function SalesReport() {
  /* O INTERVALO é a fonte única de verdade. Os presets não são um segundo
     estado paralelo: são atalhos que escrevem nele, e o segmentado só mostra
     qual deles, se algum, coincide com o intervalo atual. Dois estados para a
     mesma coisa é como um preset acaba marcado com outras datas na tela. */
  const [intervalo, setIntervalo] = useState(() => intervaloDoPreset(14))
  const [plano, setPlano] = useState('todos')
  const [hoverIdx, setHoverIdx] = useState(null)

  /* Memoizado porque entra nas dependências do cálculo abaixo — recriar o
     array a cada render faria o `useMemo` seguinte nunca acertar. */
  const visiveis = useMemo(
    () => (plano === 'todos' ? planos : planos.filter((p) => p.key === plano)),
    [plano],
  )

  const presetAtivo =
    PERIODOS.find((o) => {
      const r = intervaloDoPreset(o.value)
      return r.inicio === intervalo.inicio && r.fim === intervalo.fim
    })?.value ?? null

  const { janela, indicadores, linhas, totais, comparavel } = useMemo(() => {
    /* Uma fatia só, e tudo se refaz contra ela: gráfico, indicadores e
       tabela. Filtro que muda o estado e não muda a tela ensina a coisa
       errada — e era exatamente o que estes dois controles faziam. */
    const { inicio, fim } = intervalo
    const dentro = (d) => d.iso >= inicio && d.iso <= fim
    const janela = inicio && fim ? serie.filter(dentro) : []
    const i0 = janela.length ? serie.indexOf(janela[0]) : 0
    /* Janela anterior de mesmo tamanho, imediatamente antes. Se não couber
       inteira, não há comparação justa — 30 dias contra 12 diria qualquer
       coisa —, e o delta some em vez de mentir. */
    const anterior = serie.slice(Math.max(0, i0 - janela.length), i0)
    const comparavel = janela.length > 0 && anterior.length === janela.length

    const receita = somaJanela(janela, 'receita', visiveis)
    const pedidos = somaJanela(janela, 'pedidos', visiveis)
    const reembolsos = somaJanela(janela, 'reembolsos', visiveis)
    const ticket = pedidos > 0 ? receita / pedidos : 0

    const receitaAnt = somaJanela(anterior, 'receita', visiveis)
    const pedidosAnt = somaJanela(anterior, 'pedidos', visiveis)
    const reembolsosAnt = somaJanela(anterior, 'reembolsos', visiveis)
    const ticketAnt = pedidosAnt > 0 ? receitaAnt / pedidosAnt : 0

    const delta = (atual, anteriorValor) => (comparavel ? variacao(atual, anteriorValor) : null)

    const indicadores = [
      { label: 'Receita no período', value: brl(receita), delta: delta(receita, receitaAnt) },
      {
        label: 'Pedidos',
        value: pedidos.toLocaleString('pt-BR'),
        delta: delta(pedidos, pedidosAnt),
      },
      { label: 'Ticket médio', value: brl(ticket), delta: delta(ticket, ticketAnt) },
      {
        label: 'Reembolsos',
        value: brl(reembolsos),
        delta: delta(reembolsos, reembolsosAnt),
        /* Reembolso que sobe é notícia ruim. É o caso que expunha a confusão
           entre direção e sentido no quadrante antigo. */
        higherIsBetter: false,
      },
    ]

    /* Sem `.reverse()`: a ordem agora é da tabela, e ela nasce ordenada por
       data decrescente via `defaultSort`. Inverter aqui deixaria o estado
       inicial discordando do indicador de ordenação no cabeçalho. */
    const linhas = janela.map((d) => ({ ...d, total: somaDia(d, 'receita', visiveis) }))

    const totais = { dia: 'Total', total: receita }
    for (const p of planos) totais[p.key] = janela.reduce((a, d) => a + d.receita[p.key], 0)

    return { janela, indicadores, linhas, totais, comparavel }
  }, [intervalo, visiveis])

  const vazio = janela.length === 0

  return (
    <>
      {/* Uma linha de filtros acima de tudo que ela governa — nunca um filtro
          por card. Os presets ficam à vista porque cobrem a maioria dos casos
          em um clique; o intervalo aberto fica ao lado para o resto. Um não
          substitui o outro: obrigar a digitar duas datas para ver "7 dias" é
          tão ruim quanto só oferecer três presets fixos. */}
      <div className="flex flex-wrap items-center gap-3">
        <SegmentedControl
          ariaLabel="Período"
          value={presetAtivo}
          onChange={(v) => {
            setIntervalo(intervaloDoPreset(v))
            setHoverIdx(null)
          }}
          options={PERIODOS}
        />
        <DateRangeField
          value={intervalo}
          min={PRIMEIRO_DIA}
          max={ULTIMO_DIA}
          onChange={(v) => {
            setIntervalo(v)
            setHoverIdx(null)
          }}
        />
        <div className="w-44">
          <Select
            value={plano}
            onChange={(e) => {
              setPlano(e.target.value)
              setHoverIdx(null)
            }}
            aria-label="Plano"
          >
            <option value="todos">Todos os planos</option>
            {planos.map((p) => (
              <option key={p.key} value={p.key}>
                {p.label}
              </option>
            ))}
          </Select>
        </div>
      </div>

      <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {indicadores.map((m) => (
          <MetricCard
            key={m.label}
            label={m.label}
            value={m.value}
            delta={m.delta}
            higherIsBetter={m.higherIsBetter}
            comparison={comparavel ? `vs. ${janela.length} dias anteriores` : undefined}
          />
        ))}
      </div>

      <Card className="mt-6">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <Heading level={3}>Receita por dia</Heading>
          {/* Legenda sempre presente com 2+ séries: a identidade nunca pode
              depender só da cor. Com uma série só ela some — há uma cor
              apenas, e o título já diz o que está plotado. E some também sem
              dado: legenda de um gráfico vazio nomeia cores que não estão em
              lugar nenhum. */}
          {visiveis.length > 1 && !vazio && (
            <div className="flex flex-wrap items-center gap-4">
              {visiveis.map((p) => (
                <span key={p.key} className="flex items-center gap-1.5 text-sm text-mute">
                  <span className="h-2.5 w-2.5 rounded-sm" style={{ background: p.cor }} />
                  {p.label}
                </span>
              ))}
            </div>
          )}
        </div>
        <div className="mt-6">
          {/* Com o intervalo aberto o usuário pode escolher uma faixa sem
              dado. O gráfico não pode simplesmente sumir: ele diz o que
              houve e como sair disso. */}
          {vazio ? (
            <div className="flex h-64 flex-col items-center justify-center gap-2 text-center">
              <Text tone="mute">Nenhuma venda no intervalo escolhido.</Text>
              <Button variant="ghost" size="sm" onClick={() => setIntervalo(intervaloDoPreset(14))}>
                Voltar para os últimos 14 dias
              </Button>
            </div>
          ) : (
            <ColunaEmpilhada
              dados={janela}
              visiveis={visiveis}
              hoverIdx={hoverIdx}
              setHoverIdx={setHoverIdx}
            />
          )}
        </div>
      </Card>

      {/* A mesma série em tabela. Não é redundância: o terceiro passo da
          paleta fica abaixo de 3:1 de contraste no claro, e a tabela é o
          alívio que o guia exige para isso. */}
      <Card className="mt-6 p-0">
        <div className="flex items-center justify-between gap-4 p-5">
          <Heading level={3}>Detalhamento</Heading>
          <Badge tone="neutral">{janela.length} dias</Badge>
        </div>
        <Table
          getRowKey={(r) => r.iso}
          rows={linhas}
          /* Data decrescente por padrão: num relatório o dia mais recente é o
             que se olha primeiro. */
          defaultSort={{ key: 'dia', dir: 'desc' }}
          empty="Nenhuma venda no intervalo escolhido."
          /* O total fecha com o quadrante "Receita no período" acima. Sem ele
             os dois blocos só podem ser aceitos no voto de confiança. */
          footer={totais}
          columns={[
            /* Ordena por `iso`, não pelo rótulo: "01/07" antes de "30/06" é o
               que sai de comparar "DD/MM" como texto. */
            { key: 'dia', header: 'Dia', sortable: true, sortValue: (r) => r.iso },
            ...visiveis.map((p) => ({
              key: p.key,
              header: p.label,
              numeric: true,
              align: 'right',
              sortable: true,
              sortValue: (r) => r.receita[p.key],
              render: (r) => valorOuTraco(r.receita[p.key]),
              renderFooter: (f) => brl(f[p.key]),
            })),
            /* Com um plano só, a coluna Total repetiria a coluna do plano
               linha por linha. Coluna que duplica outra é peso morto. */
            ...(visiveis.length > 1
              ? [
                  {
                    key: 'total',
                    header: 'Total',
                    numeric: true,
                    align: 'right',
                    sortable: true,
                    render: (r) => (
                      <span className="font-semibold text-ink">{valorOuTraco(r.total)}</span>
                    ),
                    renderFooter: (f) => brl(f.total),
                  },
                ]
              : []),
          ]}
        />
      </Card>

      {/* EM ABERTO — o que esta tela revelou que ainda falta:
          · ordenação e paginação na Table (aqui são até 30 linhas; com 500 não são)
          · seletor de intervalo de datas (o segmentado só cobre presets)
          · estado vazio e estado de carregamento
          · sparkline no MetricCard — o contrato do guia prevê, e aqui haveria
            série diária para alimentar. Fica para quando um segundo painel
            pedir, para não congelar a API do componente na primeira tela.
          · o gráfico ainda vive no exemplo, pela mesma razão. */}
    </>
  )
}
