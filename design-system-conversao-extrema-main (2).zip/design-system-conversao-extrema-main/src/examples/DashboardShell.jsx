import { useState } from 'react'
import {
  House,
  ChartLine,
  Users,
  ShoppingCart,
  Gear,
  MagnifyingGlass,
  Bell,
  SignOut,
  DownloadSimple,
  Compass,
} from '@phosphor-icons/react'
import {
  Container,
  Card,
  Button,
  Input,
  Text,
  Logo,
  ThemeToggle,
  SidebarNav,
  Breadcrumbs,
} from '../components/ui'
import Overview from './dashboard/Overview'
import SalesReport from './dashboard/SalesReport'

/**
 * DashboardShell — TESTE DE PRESSÃO, não um componente da biblioteca.
 *
 * O design system foi calibrado para a landing. Esta tela existe para submetê-lo
 * a uma densidade de aplicação (sidebar + topbar + tabela) e deixar os atritos
 * aparecerem, em vez de descobri-los um a um em projetos reais.
 *
 * REGRA: monta com os componentes como eles são hoje, sem gambiarra e sem
 * `className` corretivo. Onde ficar ruim, é sinal — não é para consertar aqui.
 * Os pontos observados estão anotados com PRESSÃO ao longo do arquivo.
 *
 * O shell é dono do cromo (barra lateral, topo, cabeçalho de página) e as
 * páginas em `dashboard/` são só conteúdo. É essa divisão que faz um relatório
 * virar uma tela do sistema em vez de uma aba solta ao lado dele.
 */

const grupos = [
  {
    items: [
      { key: 'overview', icon: House, label: 'Visão geral' },
      { key: 'reports', icon: ChartLine, label: 'Relatórios', items: [
        { key: 'reports-sales', label: 'Vendas por período' },
        { key: 'reports-cohort', label: 'Coortes' },
        { key: 'reports-funnel', label: 'Funil' },
      ] },
    ],
  },
  {
    label: 'Gestão',
    items: [
      { key: 'students', icon: Users, label: 'Alunos', badge: '1.284' },
      { key: 'sales', icon: ShoppingCart, label: 'Vendas', items: [
        { key: 'sales-orders', label: 'Pedidos' },
        { key: 'sales-refunds', label: 'Reembolsos' },
      ] },
    ],
  },
  {
    label: 'Sistema',
    items: [{ key: 'settings', icon: Gear, label: 'Configurações' }],
  },
]

/**
 * A trilha não é escrita à mão em cada página: ela é derivada da própria
 * árvore de navegação. Escrever as duas separadamente é garantir que uma hora
 * elas discordem — e é a trilha que discorda calada.
 *
 * Um item intermediário sem tela própria (Relatórios) sai como texto, não como
 * link: `Breadcrumbs` já trata assim quem vem sem `href`.
 */
function trilha(key) {
  for (const grupo of grupos) {
    for (const item of grupo.items) {
      if (item.key === key) return [item.label]
      const filho = item.items?.find((c) => c.key === key)
      if (filho) return [item.label, filho.label]
    }
  }
  return []
}

/* Rotas. `acoes` é o que a página contribui para o cabeçalho — o botão vive no
   cabeçalho do shell, não dentro do conteúdo, porque é ali que ele fica na
   mesma linha do título em toda tela do sistema. */
const paginas = {
  overview: { render: () => <Overview /> },
  'reports-sales': {
    acoes: (
      <Button variant="secondary" size="field" icon={<DownloadSimple size={15} />}>
        Exportar CSV
      </Button>
    ),
    render: () => <SalesReport />,
  },
}

/* Os demais itens do menu não têm tela neste teste. Um placeholder honesto é
   melhor que um clique que não faz nada: sem ele o shell parece quebrado.
   EM ABERTO — vale virar um `EmptyState` da biblioteca; espera uma segunda
   tela pedir o mesmo. */
function EmConstrucao({ titulo }) {
  return (
    <Card className="flex flex-col items-center gap-3 py-16 text-center">
      <Compass size={28} className="text-faint" />
      <Text tone="mute">
        “{titulo}” ainda não foi montada neste teste de pressão.
      </Text>
    </Card>
  )
}

export default function DashboardShell() {
  const [current, setCurrent] = useState('overview')
  const [collapsed, setCollapsed] = useState(false)

  const caminho = trilha(current)
  const titulo = caminho[caminho.length - 1] ?? 'Painel'
  const pagina = paginas[current]

  return (
    <div className="ds-app flex min-h-screen bg-canvas">
      <SidebarNav
        className="hidden lg:flex"
        groups={grupos}
        active={current}
        onSelect={setCurrent}
        collapsed={collapsed}
        onToggleCollapsed={() => setCollapsed((v) => !v)}
        header={({ collapsed: c }) => <Logo variant={c ? 'symbol' : 'full'} className={c ? 'h-7 w-7' : 'h-6'} />}
        footer={
          <button className="flex w-full items-center gap-3 rounded-full px-3 py-2 text-sm font-medium text-mute transition-colors hover:bg-elevated hover:text-ink">
            <SignOut size={18} className="shrink-0" />
            {!collapsed && 'Sair'}
          </button>
        }
      />

      {/* ── COLUNA PRINCIPAL ─────────────────────────────────────────────── */}
      <div className="flex min-w-0 flex-1 flex-col">
        {/* TOPBAR */}
        <header className="flex h-16 shrink-0 items-center gap-4 border-b border-hairline bg-surface px-6">
          {/* A busca é o caso em que a pílula é decisão de composição, não de
              densidade: `shape="pill"` sobrepõe o canto discreto do escopo. */}
          <div className="w-full max-w-sm">
            <Input
              shape="pill"
              icon={<MagnifyingGlass size={16} />}
              placeholder="Buscar aluno, venda ou relatório…"
            />
          </div>

          <div className="ml-auto flex items-center gap-2">
            <button className="relative flex h-9 w-9 items-center justify-center rounded-md text-body transition-colors hover:bg-elevated hover:text-ink">
              <Bell size={18} />
              <span className="absolute right-2 top-2 h-1.5 w-1.5 rounded-full bg-emerald" />
            </button>
            <ThemeToggle className="h-9 w-9" />
            <div className="ml-1 flex items-center gap-2 border-l border-hairline pl-3">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-emerald/10 text-label-md font-semibold text-emerald-deep">
                TT
              </div>
              <div className="hidden leading-tight sm:block">
                <div className="text-label-md text-ink">Tiago Tessmann</div>
                <div className="text-caption text-mute">Administrador</div>
              </div>
            </div>
          </div>
        </header>

        {/* CONTEÚDO */}
        {/* RESOLVIDO — `size="fluid"` remove o teto de 1200px. A área útil já
            foi definida pela sidebar; centrar de novo só deixava faixa vazia. */}
        <main className="flex-1 overflow-auto py-8">
          <Container size="fluid">
            {/* CABEÇALHO DE PÁGINA — um só, para toda tela do sistema. */}
            <Breadcrumbs
              items={[
                {
                  label: 'Painel',
                  href: '#',
                  onClick: (e) => {
                    e.preventDefault()
                    setCurrent('overview')
                  },
                },
                ...caminho.map((label) => ({ label })),
              ]}
            />
            <div className="mt-2 flex flex-wrap items-center justify-between gap-4">
              <h1 className="text-heading-xl text-ink">{titulo}</h1>
              {pagina?.acoes}
            </div>

            <div className="mt-8">
              {pagina ? pagina.render() : <EmConstrucao titulo={titulo} />}
            </div>
          </Container>
        </main>
      </div>
    </div>
  )
}
